import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {OpportunityService} from '../core/_api/opportunity.service';
import {Router} from '@angular/router';
import {GspDialogsComponent} from '../gsp-dialogs/gsp-dialogs.component';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-gsp-opportunities',
  templateUrl: './gsp-opportunities.component.html',
  styleUrls: ['./gsp-opportunities.component.scss']
})
export class GspOpportunitiesComponent implements OnInit {

  constructor(private opportunityApi: OpportunityService , private route: Router ,private http:HttpClient) {}

  filterArr: any;
 
  sampleObj = [
    {
      'opportunityName' : 'Boxeo',
      'opportunityClient' : 'CS0000706',
      'flag1' : 'billable',
      'alerts' :
      [{
          'title'  : 'Critical'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Toshiba',
      'opportunityClient' : 'CS0000707',
      'flag1' : 'investment',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Google',
      'opportunityClient' : 'CS0000708',
      'flag1' : 'non-billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Cloud',
      'opportunityClient' : 'CS0000709',
      'flag1' : 'billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Clean&Calibrate',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Mythri',
      'opportunityClient' : 'CS0000710',
      'flag1' : 'non-billable',
      'alerts' :
      [
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Clean&Calibrate',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Kaola',
      'opportunityClient' : 'CS0000711',    
        'flag1' : 'billable',
      'alerts' :
      [
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Clean&Calibrate',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Kotak',
      'opportunityClient' : 'CS0000712',
      'flag1' : 'non-billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Clean&Calibrate',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Corporation',
      'opportunityClient' : 'CS0000713',
      'flag1' : 'investment',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Clean&Calibrate',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Mizuce',
      'opportunityClient' : 'CS0000714',
      'flag1' : 'investment',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Loop',
      'opportunityClient' : 'CS0000715',
      'flag1' : 'investment',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Nissan',
      'opportunityClient' : 'CS0000716',
      'flag1' : 'investment',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Preventive Maintenance',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'UHG',
      'opportunityClient' : 'CS0000717',
      'flag1' : 'non-billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Preventive Maintenance',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Oneweb',
      'opportunityClient' : 'CS0000718',
      'flag1' : 'billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'Preventive Maintenance',
      'cost' : 'P10000711'
    },
    {
      'opportunityName' : 'Snow',
      'opportunityClient' : 'CS0000719',
      'flag1' : 'billable',
      'alerts' :
      [{
          'title'  : 'Renewal'
      },
      {
        'title'  : 'Warning'
      }],
      'date' : '28-06-2016',
      'type' : 'BreakFix',
      'cost' : 'P10000711'
    }

  ];

  idCount = 0 ;
  users:any;
  ngOnInit() {
    this.sampleObj.forEach(sampleObj => {
      sampleObj['id'] = this.idCount + 1;
      this.idCount++;
    });
    // this.http.get<any>('https://dev82891.service-now.com/api/now/table/sys_user?sysparm_fields=first_name,last_name,email,sys_created_on').subscribe( res => {


    //   // let's take the response, parse the dates and store it in a users array
    //   this.users = res.result.map( user => {
    //     user.sys_created_on = new Date(user.sys_created_on);
    //     console.log(user);
    //     return user;
  
    //   // a quick and dirty sort...
    //   }).sort( (a,b) => `${a.first_name}${a.last_name}` < `${b.first_name}${b.last_name}` ? - 1 : 1);
  
    // });
  }
  
  refreshingModalBeforeOpening(){
    console.log("Escaping error");
  }

  goToDetailView(opportunityId: number) {
    this.route.navigate(['/opportunityDetail/' + `${opportunityId}`]).then(r => console.log(r));
  }

}
