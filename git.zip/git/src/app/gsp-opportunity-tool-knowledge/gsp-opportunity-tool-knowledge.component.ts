import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-tool-knowledge',
  templateUrl: './gsp-opportunity-tool-knowledge.component.html',
  styleUrls: ['./gsp-opportunity-tool-knowledge.component.scss']
})
export class GspOpportunityToolKnowledgeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
