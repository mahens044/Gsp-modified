import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-detail-workorder',
  templateUrl: './gsp-opportunity-detail-workorder.component.html',
  styleUrls: ['./gsp-opportunity-detail-workorder.component.scss']
})
export class GspOpportunityDetailWorkorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  openInDetail(){
    console.log("Opened");
  }
}
