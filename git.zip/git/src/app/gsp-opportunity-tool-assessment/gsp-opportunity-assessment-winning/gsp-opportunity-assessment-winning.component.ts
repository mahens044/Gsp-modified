import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-assessment-winning',
  templateUrl: './gsp-opportunity-assessment-winning.component.html',
  styleUrls: ['./gsp-opportunity-assessment-winning.component.scss']
})
export class GspOpportunityAssessmentWinningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
